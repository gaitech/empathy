<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'guru_empathy.dev');

/** MySQL database username */
define('DB_USER', 'guru');

/** MySQL database password */
define('DB_PASSWORD', 'guru!@#');

/** MySQL hostname */
define('DB_HOST', '192.168.1.252');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase /empathy/
RewriteRule ^index\.php$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /empathy/index.php [L]
</IfModule>

 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase /empathy/
RewriteRule ^index\.php$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /empathy/index.php [L]
</IfModule>

 */
define('AUTH_KEY',         '5jOzKF@OyNCZi^Ye=Lwrw=D?k[4$!EB*D*ygcX@c@TVhvq;8^?{fSi[x-]|C|;,V');
define('SECURE_AUTH_KEY',  ',Ktr**wy6bF(Ir]?tug%Y,N7 w_:S1TjnDV08</Zs4a(:lp~JLt?)A{ukk!n#U]_');
define('LOGGED_IN_KEY',    ':3VO!aFr@u#8bdQ-SJF__MHm!N1w!/e%]e[aH<@aAWeZlsvSH<mZLPOR6fslP6Qy');
define('NONCE_KEY',        '}=FLenUUdS5yk-F~o+[(x/V&RfI$&o/+:DL@!qI~]WJ5c&tn6r$bm6b@jIzxuN[&');
define('AUTH_SALT',        'WNKGr2SKA_QuhEI9v]bfF~yM3%)vRz[.*HbKc)84?.m4Gmpn!Kq{[D#jMm][vL&z');
define('SECURE_AUTH_SALT', ':,flt[xWIG|V<a,.mlolU(p&Sa:2JD;FCm<xXC#?cqkpXX#h>5OBj1@d!.h?~<Y7');
define('LOGGED_IN_SALT',   '??JU5,J~-w;JC,/L?I1vfC9R!w&k-Cc(YRj@.xLm`~8@~2)]hV[S/:s}Gs[[.K6m');
define('NONCE_SALT',       'fx2JO|oh5_}c9%b2p%_M;4_fFb&K]T7[a&Maq&lSgsa9^hj,1aV:?aD.JiBc_9)J');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);
define('FS_METHOD', 'direct');
/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
